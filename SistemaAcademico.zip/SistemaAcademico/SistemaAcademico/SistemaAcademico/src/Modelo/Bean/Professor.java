
package Modelo.Bean;


public class Professor extends Usuario {

String Disciplina;


private String getDisciplina() {
	return Disciplina;
}
private void setDisciplina(String disciplina) {
	Disciplina = disciplina;
}
private int getMatricula() {
	return Matricula;
}
private void setMatricula(int matricula) {
	Matricula = matricula;
}

 


}