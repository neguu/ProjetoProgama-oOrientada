package Modelo.Bean;

import java.util.ArrayList;

/**
 *
 * @author ifpb
 */
public class Escola {

    public ArrayList<Usuario> usuarios = new ArrayList<Usuario>();
    public ArrayList<Diario> diarios = new ArrayList<Diario>();

    public Escola() {
        Aluno aluno1 = new Aluno();
        Aluno aluno2 = new Aluno();
        Professor prof1 = new Professor();

        prof1.setNome("PPP");
        prof1.setLogin("prof");
        prof1.setSenha("123");
        prof1.setEmail("emaiewq1@g1");
        prof1.adicionarDisciplina("geografia");

        aluno1.setAno(1);
        aluno1.setNome("AAAAA");
        aluno1.setTelefone("988747743");
        aluno1.setLogin("oi");
        aluno1.setSenha("123");
        aluno1.setEmail("emai1@g1");
        aluno2.setSenha("123");
        aluno2.setAno(2);
        aluno2.setNome("NOME2");
        aluno2.setEmail("emai2ffwefewfwefewfwefwefwefwef@g2PAra diferenciasr");
        aluno1.setCPF(231654);

        usuarios.add(aluno2);
        usuarios.add(aluno1);
        usuarios.add(prof1);
    }

    public int compare(Usuario o1, Usuario o2) {
        return o1.getNome().compareTo(o2.getNome());
    }

}
