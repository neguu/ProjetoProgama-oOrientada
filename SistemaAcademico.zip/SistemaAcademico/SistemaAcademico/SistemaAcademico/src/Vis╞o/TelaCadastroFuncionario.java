

package Visão;
import Modelo.Bean.Aluno;
import Modelo.Bean.Escola;
import Modelo.Bean.Professor;
import Modelo.Bean.Técnico;
import Modelo.Bean.Usuario;
import java.util.ArrayList;

import javax.swing.JOptionPane;
import javax.swing.JTextField;


public class TelaCadastroFuncionario extends javax.swing.JFrame {

    
    Escola escola = new Escola();
    
    public TelaCadastroFuncionario(Escola escola) {
        this.escola = escola;
        initComponents();
    }

    
    public TelaCadastroFuncionario() {
        initComponents();
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPasswordField2 = new javax.swing.JPasswordField();
        text = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        Nome = new javax.swing.JTextField();
        MatriculaDoFuncionário = new javax.swing.JTextField();
        CPFDoFuncionário = new javax.swing.JTextField();
        SenhaDoFuncionario = new javax.swing.JPasswordField();
        ComfirmaçãoDaSenha = new javax.swing.JPasswordField();
        LoginDoFuncionário = new javax.swing.JTextField();
        ConfirmaçãodCadastro = new javax.swing.JButton();
        Email = new javax.swing.JTextField();
        Telefone = new javax.swing.JTextField();
        Professor = new javax.swing.JRadioButton();
        Tecnico = new javax.swing.JRadioButton();
        Pt = new javax.swing.JRadioButton();
        Ma = new javax.swing.JRadioButton();
        Geo = new javax.swing.JRadioButton();
        His = new javax.swing.JRadioButton();
        Filo = new javax.swing.JRadioButton();
        Socio = new javax.swing.JRadioButton();
        Qui = new javax.swing.JRadioButton();
        Fis = new javax.swing.JRadioButton();
        dsiciplina = new javax.swing.JLabel();
        javax.swing.JLabel TelaCadastroFuncionário = new javax.swing.JLabel();

        jPasswordField2.setText("jPasswordField2");

        getContentPane().setLayout(null);

        text.setFont(new java.awt.Font("长仿宋体", 1, 40)); // NOI18N
        text.setText("Casdastro de Funcionário");
        getContentPane().add(text);
        text.setBounds(130, 0, 540, 80);

        jLabel1.setFont(new java.awt.Font("Verdana", 1, 14)); // NOI18N
        jLabel1.setText("Nome do Funcionário:");
        getContentPane().add(jLabel1);
        jLabel1.setBounds(10, 80, 180, 20);

        jLabel3.setFont(new java.awt.Font("Verdana", 1, 14)); // NOI18N
        jLabel3.setText("Matricula do Funcionário: ");
        getContentPane().add(jLabel3);
        jLabel3.setBounds(0, 110, 210, 18);

        jLabel4.setFont(new java.awt.Font("Verdana", 1, 14)); // NOI18N
        jLabel4.setText("Login do Funcionário:");
        getContentPane().add(jLabel4);
        jLabel4.setBounds(10, 240, 180, 18);

        jLabel7.setFont(new java.awt.Font("Verdana", 1, 14)); // NOI18N
        jLabel7.setText("Senha do Funcionário:");
        getContentPane().add(jLabel7);
        jLabel7.setBounds(10, 280, 180, 18);

        jLabel5.setFont(new java.awt.Font("Verdana", 1, 14)); // NOI18N
        jLabel5.setText("CPF do Funcionário:");
        getContentPane().add(jLabel5);
        jLabel5.setBounds(40, 350, 160, 18);

        jLabel8.setFont(new java.awt.Font("Verdana", 1, 14)); // NOI18N
        jLabel8.setText("Confirmação da senha :");
        getContentPane().add(jLabel8);
        jLabel8.setBounds(30, 320, 190, 14);

        jLabel2.setFont(new java.awt.Font("Verdana", 1, 14)); // NOI18N
        jLabel2.setText(" Email:");
        getContentPane().add(jLabel2);
        jLabel2.setBounds(70, 160, 80, 18);

        jLabel9.setFont(new java.awt.Font("Verdana", 1, 14)); // NOI18N
        jLabel9.setText("Telefone:");
        getContentPane().add(jLabel9);
        jLabel9.setBounds(60, 200, 100, 18);

        Nome.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                NomeActionPerformed(evt);
            }
        });
        getContentPane().add(Nome);
        Nome.setBounds(190, 70, 400, 30);

        MatriculaDoFuncionário.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                MatriculaDoFuncionárioActionPerformed(evt);
            }
        });
        getContentPane().add(MatriculaDoFuncionário);
        MatriculaDoFuncionário.setBounds(200, 110, 400, 30);
        getContentPane().add(CPFDoFuncionário);
        CPFDoFuncionário.setBounds(220, 350, 220, 30);

        SenhaDoFuncionario.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SenhaDoFuncionarioActionPerformed(evt);
            }
        });
        getContentPane().add(SenhaDoFuncionario);
        SenhaDoFuncionario.setBounds(190, 270, 160, 30);

        ComfirmaçãoDaSenha.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ComfirmaçãoDaSenhaActionPerformed(evt);
            }
        });
        getContentPane().add(ComfirmaçãoDaSenha);
        ComfirmaçãoDaSenha.setBounds(220, 310, 160, 30);

        LoginDoFuncionário.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                LoginDoFuncionárioActionPerformed(evt);
            }
        });
        getContentPane().add(LoginDoFuncionário);
        LoginDoFuncionário.setBounds(190, 230, 160, 30);

        ConfirmaçãodCadastro.setFont(new java.awt.Font("Verdana", 1, 14)); // NOI18N
        ConfirmaçãodCadastro.setText("Cadastrar");
        ConfirmaçãodCadastro.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ConfirmaçãodCadastroActionPerformed(evt);
            }
        });
        getContentPane().add(ConfirmaçãodCadastro);
        ConfirmaçãodCadastro.setBounds(300, 550, 160, 40);

        Email.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EmailActionPerformed(evt);
            }
        });
        getContentPane().add(Email);
        Email.setBounds(190, 150, 400, 30);

        Telefone.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TelefoneActionPerformed(evt);
            }
        });
        getContentPane().add(Telefone);
        Telefone.setBounds(190, 190, 160, 30);

        Professor.setFont(new java.awt.Font("Verdana", 3, 12)); // NOI18N
        Professor.setText("Professor");
        Professor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ProfessorActionPerformed(evt);
            }
        });
        getContentPane().add(Professor);
        Professor.setBounds(200, 490, 110, 30);

        Tecnico.setFont(new java.awt.Font("Verdana", 3, 12)); // NOI18N
        Tecnico.setSelected(true);
        Tecnico.setText("Técnico");
        Tecnico.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TecnicoActionPerformed(evt);
            }
        });
        getContentPane().add(Tecnico);
        Tecnico.setBounds(460, 490, 110, 30);

        Pt.setText("Português ");
        getContentPane().add(Pt);
        Pt.setBounds(10, 440, 77, 23);

        Ma.setText("Matemática");
        getContentPane().add(Ma);
        Ma.setBounds(100, 440, 93, 23);

        Geo.setText("Geografia");
        getContentPane().add(Geo);
        Geo.setBounds(200, 440, 73, 23);

        His.setText("História");
        getContentPane().add(His);
        His.setBounds(280, 440, 61, 23);

        Filo.setText("Filosofia");
        getContentPane().add(Filo);
        Filo.setBounds(350, 440, 65, 23);

        Socio.setText("Sociologia");
        getContentPane().add(Socio);
        Socio.setBounds(430, 440, 73, 23);

        Qui.setText("Química");
        getContentPane().add(Qui);
        Qui.setBounds(590, 440, 93, 23);

        Fis.setText("Física");
        getContentPane().add(Fis);
        Fis.setBounds(520, 440, 51, 23);

        dsiciplina.setFont(new java.awt.Font("Verdana", 3, 14)); // NOI18N
        dsiciplina.setText("Disciplina que o Professor ensina:");
        getContentPane().add(dsiciplina);
        dsiciplina.setBounds(0, 390, 270, 30);

        Filo.show(false);
        Ma.show(false);
        Ma.show(false);
        Geo.show(false);
        Fis.show(false);
        His.show(false);
        Qui.show(false);
        Socio.show(false);
        Pt.show(false);

        dsiciplina.show(false);

        TelaCadastroFuncionário.setFont(new java.awt.Font("Malgun Gothic", 1, 18)); // NOI18N
        TelaCadastroFuncionário.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagens/telaCadastro.jpg"))); // NOI18N
        getContentPane().add(TelaCadastroFuncionário);
        TelaCadastroFuncionário.setBounds(0, 0, 885, 728);

        setSize(new java.awt.Dimension(740, 646));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void NomeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_NomeActionPerformed
       Nome.getText();
 
    }//GEN-LAST:event_NomeActionPerformed

    private void MatriculaDoFuncionárioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MatriculaDoFuncionárioActionPerformed
    
    }//GEN-LAST:event_MatriculaDoFuncionárioActionPerformed
    public boolean verificaString(String str){
            for( int index = 0; index < str.length(); index++){

                if(!Character.isLetter(str.charAt(index))){
                    return false;
                }
            }

            return true;
        }
    
    
    
    
    public ArrayList<String> disciplinasProf(){
        ArrayList<String> disciplinas = new ArrayList<String>();
        
        
          if(Filo.isSelected()){
             disciplinas.add("Filosofia");
        }
          if (Ma.isSelected()){
             disciplinas.add("Matematica");
        }
          if (Geo.isSelected()){
             disciplinas.add("Geografia");
        }
          if (His.isSelected()){
             disciplinas.add("História");
        } 
          if (Socio.isSelected()){
             disciplinas.add("Sociologia");
        }
          if (Fis.isSelected()){
             disciplinas.add("Fisica");
        }
          if (Qui.isSelected()){
             disciplinas.add("Quimica");
        }
           if (Pt.isSelected()){
             disciplinas.add("Matematica");
        }
              
            
        return  disciplinas;
    }
    private void LoginDoFuncionárioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_LoginDoFuncionárioActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_LoginDoFuncionárioActionPerformed

    public void ValidaNumero(JTextField Matricula ) {
  
        }
    private void ComfirmaçãoDaSenhaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ComfirmaçãoDaSenhaActionPerformed
       
    }//GEN-LAST:event_ComfirmaçãoDaSenhaActionPerformed

    private void EmailActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_EmailActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_EmailActionPerformed

    private void TelefoneActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TelefoneActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_TelefoneActionPerformed

    private void SenhaDoFuncionarioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SenhaDoFuncionarioActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_SenhaDoFuncionarioActionPerformed

    private void ProfessorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ProfessorActionPerformed
       Tecnico.setSelected(false);
        
        
          if (!Professor.isSelected()){
           Filo.show(false);
           Ma.show(false);
           Geo.show(false);
           Fis.show(false);
           His.show(false);
           Qui.show(false);
           Socio.show(false);
           Pt.show(false);
          
           dsiciplina.show(false);
        }
      else if(Professor.isSelected()){
        
          
           Filo.show(true);
           Ma.show(true);
           Geo.show(true);
           Fis.show(true);
           His.show(true);
           Qui.show(true);
           Socio.show(true);
           Pt.show(true);
          
           dsiciplina.show(true);
    
        }
    }//GEN-LAST:event_ProfessorActionPerformed

    private void TecnicoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TecnicoActionPerformed
     Professor.setSelected(false);
     
          if (!Professor.isSelected()){
           Filo.show(false);
           Ma.show(false);
           Ma.show(false);
           Geo.show(false);
           Fis.show(false);
           His.show(false);
           Qui.show(false);
           Socio.show(false);
           Pt.show(false);
          
           dsiciplina.show(false);
        }
      else if(Professor.isSelected()){
        
          
           Filo.show(true);
           Ma.show(true);
           Geo.show(true);
           Fis.show(true);
           His.show(true);
           Qui.show(true);
           Socio.show(true);
           Pt.show(true);
          
           dsiciplina.show(true);
    
        }
    }//GEN-LAST:event_TecnicoActionPerformed

    private void ConfirmaçãodCadastroActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ConfirmaçãodCadastroActionPerformed
        if(verificaString(Nome.getText())){
        
        if(Professor.isSelected()){
            
            
            Professor prof = new Professor();

            if(SenhaDoFuncionario.getText().equals(ComfirmaçãoDaSenha.getText())){

                try{
                    prof.setTelefone(Telefone.getText());
                    prof.setSenha(SenhaDoFuncionario.getText());

                    prof.setNome(Nome.getText());
                    prof.setEmail(Email.getText());
                    prof.setMatricula(MatriculaDoFuncionário.getText());
                    prof.setLogin(LoginDoFuncionário.getText());
                    prof.setCPF(Integer.parseInt(CPFDoFuncionário.getText()));
                    prof.setDisciplina(disciplinasProf());
                    escola.usuarios.add(prof);
                        
                    System.out.println("Visão.TelaCadastroFuncionario.ConfirmaçãodCadastroActionPerformed()");
                    System.out.println(prof.getDisciplina());
                    
                    Nome.setText("");
                    ComfirmaçãoDaSenha.setText("");
                    SenhaDoFuncionario.setText("");
                    LoginDoFuncionário.setText("");
                    MatriculaDoFuncionário.setText("");
                    CPFDoFuncionário.setText("");

                    Corfimação c = new Corfimação(escola);
                    c.setVisible(true);
                    dispose();
                
                }catch(NumberFormatException ex){
                    JOptionPane.showMessageDialog(null,"Esse Campo só aceita números" );

                }

            }
        }else if(Tecnico.isSelected()){
                       
                        
                        Técnico tec = new Técnico();

            if(SenhaDoFuncionario.getText().equals(ComfirmaçãoDaSenha.getText())){

                try{
                    tec.setTelefone(Telefone.getText());
                    tec.setSenha(SenhaDoFuncionario.getText());

                    tec.setNome(Nome.getText());
                    tec.setEmail(Email.getText());
                    tec.setMatricula(MatriculaDoFuncionário.getText());
                    tec.setLogin(LoginDoFuncionário.getText());
                    tec.setCPF(Integer.parseInt(CPFDoFuncionário.getText()));
                   
                    escola.usuarios.add(tec);

                    Nome.setText("");
                    ComfirmaçãoDaSenha.setText("");
                    SenhaDoFuncionario.setText("");
                    LoginDoFuncionário.setText("");
                    MatriculaDoFuncionário.setText("");
                    CPFDoFuncionário.setText("");

                    
                    
                    
                    
                    
                    
                    Corfimação c = new Corfimação(escola);
                    c.setVisible(true);
                    dispose();
                    
                    
                }catch(NumberFormatException ex){
                    JOptionPane.showMessageDialog(null,"Esse Campo só aceita números" );

                }
}else{
                JOptionPane.showMessageDialog(null,"Selecione a opção Funcionário ou Professor" );
            }

                  
        }
        }
    }//GEN-LAST:event_ConfirmaçãodCadastroActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
 
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new TelaCadastroFuncionario().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField CPFDoFuncionário;
    private javax.swing.JPasswordField ComfirmaçãoDaSenha;
    private javax.swing.JButton ConfirmaçãodCadastro;
    private javax.swing.JTextField Email;
    private javax.swing.JRadioButton Filo;
    private javax.swing.JRadioButton Fis;
    private javax.swing.JRadioButton Geo;
    private javax.swing.JRadioButton His;
    private javax.swing.JTextField LoginDoFuncionário;
    private javax.swing.JRadioButton Ma;
    private javax.swing.JTextField MatriculaDoFuncionário;
    private javax.swing.JTextField Nome;
    private javax.swing.JRadioButton Professor;
    private javax.swing.JRadioButton Pt;
    private javax.swing.JRadioButton Qui;
    private javax.swing.JPasswordField SenhaDoFuncionario;
    private javax.swing.JRadioButton Socio;
    private javax.swing.JRadioButton Tecnico;
    private javax.swing.JTextField Telefone;
    private javax.swing.JLabel dsiciplina;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPasswordField jPasswordField2;
    private javax.swing.JLabel text;
    // End of variables declaration//GEN-END:variables
}
