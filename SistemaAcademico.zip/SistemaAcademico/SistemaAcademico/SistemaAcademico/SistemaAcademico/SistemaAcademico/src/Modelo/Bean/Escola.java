package Modelo.Bean;

import java.util.ArrayList;

/**
 *
 * @author ifpb
 */
public class Escola {

    public ArrayList<Usuario> usuarios = new ArrayList<Usuario>();
    public ArrayList<Diario> diarios = new ArrayList<Diario>();

    public Escola() {
        

        
        

      
    }

    public int compare(Usuario o1, Usuario o2) {
        return o1.getNome().compareTo(o2.getNome());
    }

}
