
package Modelo.Bean;


public class Diario {
    
    String disciplina;
    Professor professor;
    
    public String getDisciplina() {
        return disciplina;
    }

    public void setDisciplina(String disciplina) {
        this.disciplina = disciplina;
    }

    public void setProfessor(Professor p) {
        this.professor = p;
    }
    public Professor getProfessor(){
        return professor;
    }
    
    
}
