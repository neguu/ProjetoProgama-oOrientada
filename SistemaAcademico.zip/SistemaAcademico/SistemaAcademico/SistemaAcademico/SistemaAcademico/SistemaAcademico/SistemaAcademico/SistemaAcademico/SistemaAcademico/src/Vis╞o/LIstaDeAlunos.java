/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Visão;

import Modelo.Bean.Aluno;
import Modelo.Bean.Escola;
import Modelo.Bean.Professor;
import Modelo.Bean.Técnico;
import Modelo.Bean.Usuario;
import database.UsuarioDAO;
import java.util.Collection;
import java.util.Collections;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author ifpb
 */
public class LIstaDeAlunos extends javax.swing.JFrame {

    private Usuario[] usuarios = new Usuario[1000];
    private Escola escola = new Escola();

    /**
     * Creates new form LIstaDeusuarios
     */
    public void organizador(Escola esc) {
        DefaultTableModel modelo = new DefaultTableModel();
        modelo.addColumn("Nome");
        modelo.addColumn("matricula");
        modelo.addColumn("Email");
        modelo.addColumn("Telefone");
        modelo.addColumn("CPF");
        modelo.addColumn("ano");
        modelo.addColumn("Tipo");

        Usuario u = new Usuario();
        Aluno a = new Aluno();
        int matricula = a.getMatricula();
        //System.out.println(matricula);
        //System.out.println(this.escola.usuarios);
        String tipo = "";
        String ano = "-";

        try {
            if (this.escola.usuarios.size() == 0) {
                modelo.addRow(new String[]{"Sem Dados", "Sem Dados"});
            } else {
                modelo.setNumRows(0);
                this.escola.usuarios.sort((o1, o2) -> {
                    return o1.getNome().compareTo(o2.getNome()); //To change body of generated lambdas, choose Tools | Templates.
                });
                for (Usuario user : this.escola.usuarios) {

                    String tel = "" + user.getTelefone();
                    //System.out.println("Visão.LIstaDeAlunos.organizador()");
                    if (user.getNome().contains(PesquisarNome.getText()) && tel.contains(PesquisarTelefone.getText())) {

                        //System.out.println("Visão.LIstaDeAlunos.orgadasdsadsadsadsadsadsad");
                        //System.out.println(user instanceof Aluno);
                        if (user instanceof Aluno) {
                            if (!Aluno.isSelected()) {
                                continue;
                            }

                            tipo = "Aluno";
                            ano = "" + user.getAno();

                        }
                        if (user instanceof Técnico) {
                            tipo = "Tecnico";
                             ano = "--";
                        }
                        
                        if (user instanceof Professor) {
                            if (!professor.isSelected()) {
                                continue;
                            }
                            tipo = "Professor";
                            ano = "--";
                        }
                        modelo.addRow(new Object[]{
                            user.getNome(),
                            user.getMatricula(),
                            user.getEmail(),
                            user.getTelefone(),
                            user.getCPF(),
                            ano,
                            tipo,});
                    }
                }
            }
            TabelaAluno.setModel(modelo);

            System.out.println(TabelaAluno.getValueAt(0, 0));
        } catch (Exception e) {
            System.out.println(e);
            modelo.addRow(new String[]{"Sem Dados", "Sem Dados"});
            TabelaAluno.setModel(modelo);
            System.out.println("Acerteiiiii, concertezxa");
        }
    }

    public LIstaDeAlunos() {
        initComponents();
        UsuarioDAO usuarioDAO = new UsuarioDAO();
        this.escola.usuarios.addAll(usuarioDAO.verTodosAlunos()); // Alunos
        this.escola.usuarios.addAll(usuarioDAO.verTodosProfessor());//Professor
        this.escola.usuarios.addAll(usuarioDAO.verTodosTecnico());//tecnicos

    }

    LIstaDeAlunos(Usuario[] usuarios) {
        this.usuarios = usuarios;
        UsuarioDAO usuarioDAO = new UsuarioDAO();
        this.escola.usuarios.addAll(usuarioDAO.verTodosAlunos()); // Alunos
        this.escola.usuarios.addAll(usuarioDAO.verTodosProfessor());//Professor
        this.escola.usuarios.addAll(usuarioDAO.verTodosTecnico());//tecnicos
    }

    LIstaDeAlunos(Escola escola) {

        initComponents();
        this.escola = escola;
        UsuarioDAO usuarioDAO = new UsuarioDAO();
        this.escola.usuarios.addAll(usuarioDAO.verTodosAlunos()); // Alunos
        this.escola.usuarios.addAll(usuarioDAO.verTodosProfessor());//Professor
        this.escola.usuarios.addAll(usuarioDAO.verTodosTecnico());//tecnicos

    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        Atualizar = new javax.swing.JButton();
        Voltar = new javax.swing.JButton();
        Deletar = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        TabelaAluno = new javax.swing.JTable();
        PesquisarNome = new javax.swing.JTextField();
        Aluno = new javax.swing.JRadioButton();
        professor = new javax.swing.JRadioButton();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        PesquisarTelefone = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(null);

        Atualizar.setFont(new java.awt.Font("Verdana", 3, 14)); // NOI18N
        Atualizar.setText("Atualizar");
        Atualizar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AtualizarActionPerformed(evt);
            }
        });
        getContentPane().add(Atualizar);
        Atualizar.setBounds(430, 50, 130, 30);

        Voltar.setFont(new java.awt.Font("Verdana", 3, 14)); // NOI18N
        Voltar.setText("voltar");
        Voltar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                VoltarActionPerformed(evt);
            }
        });
        getContentPane().add(Voltar);
        Voltar.setBounds(50, 60, 110, 27);

        Deletar.setFont(new java.awt.Font("Verdana", 3, 14)); // NOI18N
        Deletar.setText("Delete");
        Deletar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                DeletarMouseClicked(evt);
            }
        });
        Deletar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DeletarActionPerformed(evt);
            }
        });
        getContentPane().add(Deletar);
        Deletar.setBounds(230, 10, 120, 40);

        TabelaAluno.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "Nome", "Matricula ", "Email", "Telefone", "CPF", "Tipo"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.Object.class, java.lang.Object.class, java.lang.Object.class, java.lang.Object.class, java.lang.Object.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(TabelaAluno);

        getContentPane().add(jScrollPane1);
        jScrollPane1.setBounds(80, 200, 480, 120);

        PesquisarNome.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                PesquisarNomeActionPerformed(evt);
            }
        });
        getContentPane().add(PesquisarNome);
        PesquisarNome.setBounds(110, 160, 170, 20);

        Aluno.setSelected(true);
        Aluno.setText("Aluno");
        getContentPane().add(Aluno);
        Aluno.setBounds(160, 120, 60, 23);

        professor.setSelected(true);
        professor.setText("Professor");
        getContentPane().add(professor);
        professor.setBounds(380, 120, 71, 23);

        jLabel1.setFont(new java.awt.Font("Times New Roman", 3, 14)); // NOI18N
        jLabel1.setText("Nome:");
        getContentPane().add(jLabel1);
        jLabel1.setBounds(60, 160, 50, 20);

        jLabel2.setFont(new java.awt.Font("Times New Roman", 3, 14)); // NOI18N
        jLabel2.setText("Telefone:");
        getContentPane().add(jLabel2);
        jLabel2.setBounds(300, 160, 60, 20);
        getContentPane().add(PesquisarTelefone);
        PesquisarTelefone.setBounds(360, 160, 200, 20);

        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagens/prof_1.jpg"))); // NOI18N
        getContentPane().add(jLabel3);
        jLabel3.setBounds(0, 0, 620, 390);

        setSize(new java.awt.Dimension(641, 435));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void VoltarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_VoltarActionPerformed
        TelaPrincipal tp = new TelaPrincipal();
        tp.setVisible(true);
        dispose();


    }//GEN-LAST:event_VoltarActionPerformed

    private void AtualizarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AtualizarActionPerformed

        organizador(escola);

    }//GEN-LAST:event_AtualizarActionPerformed

    private void DeletarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DeletarActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_DeletarActionPerformed

    private void DeletarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_DeletarMouseClicked

        int posicao = TabelaAluno.getSelectedRow();
        int matricula = (int) TabelaAluno.getValueAt(posicao, 1);

        for (Usuario user : this.escola.usuarios) {
            if (user instanceof Aluno) {
                UsuarioDAO usuarioDAO = new UsuarioDAO();
                usuarioDAO.excluirPessoa(matricula, user);
            } else if (user instanceof Professor) {
                UsuarioDAO usuarioDAO = new UsuarioDAO();
                usuarioDAO.excluirPessoa(matricula, user);
            } else if (user instanceof Técnico) {
                UsuarioDAO usuarioDAO = new UsuarioDAO();
                usuarioDAO.excluirPessoa(matricula, user);
            }
        }

        if (posicao != -1) {
            this.escola.usuarios.remove(posicao);

            DefaultTableModel modelo = (DefaultTableModel) TabelaAluno.getModel();
            modelo.setNumRows(0);

            for (Usuario user : this.escola.usuarios) {
                modelo.addRow(new Object[]{
                    user.getNome(),
                    user.getMatricula(),
                    user.getEmail(),
                    user.getTelefone(),
                    user.getCPF(),});

            }
        }
    }//GEN-LAST:event_DeletarMouseClicked

    private void PesquisarNomeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PesquisarNomeActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_PesquisarNomeActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(LIstaDeAlunos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(LIstaDeAlunos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(LIstaDeAlunos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(LIstaDeAlunos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new LIstaDeAlunos().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JRadioButton Aluno;
    private javax.swing.JButton Atualizar;
    private javax.swing.JButton Deletar;
    private javax.swing.JTextField PesquisarNome;
    private javax.swing.JTextField PesquisarTelefone;
    private javax.swing.JTable TabelaAluno;
    private javax.swing.JButton Voltar;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JRadioButton professor;
    // End of variables declaration//GEN-END:variables
}
