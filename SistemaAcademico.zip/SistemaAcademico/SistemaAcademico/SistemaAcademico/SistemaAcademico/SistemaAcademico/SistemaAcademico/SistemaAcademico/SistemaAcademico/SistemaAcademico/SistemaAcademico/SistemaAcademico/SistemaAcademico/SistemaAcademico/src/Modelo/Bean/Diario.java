
package Modelo.Bean;

import java.util.ArrayList;


public class Diario {
    
    String disciplina;
    Professor professor;

    public ArrayList<Aluno> getAlunos() {
        return alunos;
    }

    public void setAlunos(ArrayList<Aluno> alunos) {
        this.alunos = alunos;
    }
    ArrayList<Aluno> alunos = new ArrayList<Aluno>();
    
    public String getDisciplina() {
        return disciplina;
    }

    public void setDisciplina(String disciplina) {
        this.disciplina = disciplina;
    }

    public void setProfessor(Professor p) {
        this.professor = p;
    }
    public Professor getProfessor(){
        return professor;
    }

    public void adicionarAluno(Aluno a){
        alunos.add(a);
    }
    
    
}
