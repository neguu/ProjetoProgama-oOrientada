package database;

import Modelo.Bean.Aluno;
import Modelo.Bean.Diario;
import Modelo.Bean.Professor;
import Modelo.Bean.Técnico;
import Modelo.Bean.Usuario;
import static com.sun.org.apache.xalan.internal.xsltc.compiler.util.Type.Int;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;

import java.sql.ResultSet;
import java.util.HashMap;

public class UsuarioDAO {

    private ConexaoBD conexao;

    public UsuarioDAO() {
        // cria o objeto para conex�o com banco, por�m n�o o inicializa
        // a conex�o deve ser aberta e, consequentemente, fechada durante o envio de comandos
        // ao banco
        this.conexao = new ConexaoBD();
    }

    public void inserirAlunoDiario(int matriculaAluno, int matriculaProfessor) {
        conexao.conectar();

        try {
            PreparedStatement stm = conexao.getConexao().prepareStatement("insert into diario(aluno,professor) values(?,?)");
            stm.setInt(1, matriculaAluno);
            stm.setInt(2, matriculaProfessor);

            stm.execute();

        } catch (Exception e) {
            System.out.println(e);
        } finally {
            // o banco deve ser desconectado, mesmo quando a exce��o � lan�ada
            conexao.desconectar();
        }
    }

    public void criarPessoa(Usuario u) {
        // abrindo a conex�o com o BD
        conexao.conectar();

        try {
            if (u instanceof Aluno) {
                // usando um PreparedStatement com valores externos como par�metros (representados pelo '?')
                PreparedStatement pst = conexao.getConexao().prepareStatement("insert into aluno(nome,email,telefone,login,senha,cpf,ano,matricula) values(?,?,?,?,?,?,?,?)");
                // os m�todos set devem ser escolhidos de acordo com os tipos dos atributos da entidade que est�
                // sendo acessada. A sequ�ncia � determinada por �ndices, iniciando do valor 1.
                pst.setString(1, u.getNome());
                pst.setString(2, u.getEmail());
                pst.setString(3, u.getTelefone());
                pst.setString(4, u.getLogin());
                pst.setString(5, u.getSenha());
                pst.setInt(6, u.getCPF());
                pst.setInt(7, u.getAno());
                //System.out.println(u.getMatricula());
                pst.setInt(8, u.getMatricula());

                // solicita��o da execu��o da query, ap�s seu preparo
                pst.execute();

            } else if (u instanceof Professor) {
                // usando um PreparedStatement com valores externos como par�metros (representados pelo '?')
                PreparedStatement pst = conexao.getConexao().prepareStatement("insert into professor(nome,email,telefone,login,senha,cpf,matricula,disciplina) values(?,?,?,?,?,?,?,?)");
                // os m�todos set devem ser escolhidos de acordo com os tipos dos atributos da entidade que est�
                // sendo acessada. A sequ�ncia � determinada por �ndices, iniciando do valor 1.
                pst.setString(1, u.getNome());
                pst.setString(2, u.getEmail());
                pst.setString(3, u.getTelefone());
                pst.setString(4, u.getLogin());
                pst.setString(5, u.getSenha());
                pst.setInt(6, u.getCPF());
                pst.setInt(7, u.getMatricula());
                Professor p = (Professor) u;
                pst.setString(8, u.getDisciplina());

                // solicita��o da execu��o da query, ap�s seu preparo
                pst.execute();

            } else if (u instanceof Técnico) {
                // usando um PreparedStatement com valores externos como par�metros (representados pelo '?')
                PreparedStatement pst = conexao.getConexao().prepareStatement("insert into tecnico(nome,email,telefone,login,senha,cpf,matricula) values(?,?,?,?,?,?,?)");
                // os m�todos set devem ser escolhidos de acordo com os tipos dos atributos da entidade que est�
                // sendo acessada. A sequ�ncia � determinada por �ndices, iniciando do valor 1.
                pst.setString(1, u.getNome());
                pst.setString(2, u.getEmail());
                pst.setString(3, u.getTelefone());
                pst.setString(4, u.getLogin());
                pst.setString(5, u.getSenha());
                pst.setInt(6, u.getCPF());
                pst.setInt(7, u.getMatricula());

                // solicita��o da execu��o da query, ap�s seu preparo
                pst.execute();

            }

        } catch (SQLException e) {
            System.out.println("Erro: " + e.getMessage());
        } finally {
            // o banco deve ser desconectado, mesmo quando a exce��o � lan�ada
            conexao.desconectar();
        }

    }

    public Aluno buscarAluno(int matricula) {
        // abrindo a conexão com o BD
        conexao.conectar();
        // busca utilizando o método de consulta do objeto ConexaoBD
        ResultSet resultado = conexao.executarSQL("select * from aluno where matricula = \'" + matricula + "\'");
        Aluno a = new Aluno();

        try {
            resultado.next();
            // os métodos get devem ser escolhidos de acordo com os tipos dos atributos da entidade que está
            // sendo acessada
            String nome = resultado.getString("nome");
            int ano = resultado.getInt("ano");
            int cpf = resultado.getInt("cpf");
            String email = resultado.getString("email");
            String telefone = resultado.getString("telefone");
            String login = resultado.getString("login");
            String senha = resultado.getString("senha");
            int mat = resultado.getInt("matricula");

            // System.out.println("database.UsuarioDAO.verTodosAlunos()");
            a.setEmail(email);
            a.setTelefone(telefone);
            a.setLogin(login);
            a.setSenha(senha);
            a.setMatricula(matricula);
            a.setAno(ano);
            a.setCPF(cpf);
            a.setNome(nome);

        } catch (SQLException e) {
            System.out.println("Erro: " + e.getMessage());
        } finally {
            // o banco deve ser desconectado, mesmo quando a exceção é lançada
            conexao.desconectar();
        }
        return a;
    }

    public Professor buscarProfessor(int matricula) {
        // abrindo a conexão com o BD
        conexao.conectar();
        // busca utilizando o método de consulta do objeto ConexaoBD
        ResultSet resultado = conexao.executarSQL("select * from professor where matricula = \'" + matricula + "\'");
        Professor p = new Professor();

        try {
            resultado.next();
            
            String nome = resultado.getString("nome");
            String disciplina = resultado.getString("disciplina");
            int cpf = resultado.getInt("cpf");
            String email = resultado.getString("email");
            String telefone = resultado.getString("telefone");
            String login = resultado.getString("login");
            String senha = resultado.getString("senha");
            int mat = resultado.getInt("matricula");
            

            // System.out.println("database.UsuarioDAO.verTodosAlunos()");
            p.setEmail(email);
            p.setTelefone(telefone);
            p.setLogin(login);
            p.setSenha(senha);
            p.setMatricula(matricula);
            ArrayList<String> disciplinas = new ArrayList<>();
            disciplinas.add(disciplina);
            p.setDisciplina(disciplinas);
            p.setCPF(cpf);
            p.setNome(nome);

        } catch (SQLException e) {
            System.out.println("Erro: " + e.getMessage());
        } finally {
            // o banco deve ser desconectado, mesmo quando a exceção é lançada
            conexao.desconectar();
        }
        return p;
    }

    public void excluirPessoa(int matricula, Usuario u) {
        // abrindo a conex�o com o BD
        conexao.conectar();

        try {
            if (u instanceof Aluno) {
                PreparedStatement stm1 = conexao.getConexao().prepareStatement("delete from diario where aluno = \'" + matricula + "\'");
                stm1.execute();
                PreparedStatement stm2 = conexao.getConexao().prepareStatement("delete from aluno where matricula = \'" + matricula + "\'");
                stm2.execute();
            } else if (u instanceof Professor) {
                PreparedStatement stm1 = conexao.getConexao().prepareStatement("delete from diario where professor = \'" + matricula + "\'");
                stm1.execute();
                PreparedStatement stm2 = conexao.getConexao().prepareStatement("delete from professor where matricula = \'" + matricula + "\'");
                stm2.execute();
            } else if (u instanceof Técnico) {
                PreparedStatement stm = conexao.getConexao().prepareStatement("delete from tecnico where matricula = \'" + matricula + "\'");
                stm.execute();

            }

        } catch (SQLException e) {
            System.out.println("Erro: " + e.getMessage());
        } finally {
            // o banco deve ser desconectado, mesmo quando a exce��o � lan�ada
            conexao.desconectar();
        }
    }

    public void editarAluno(Usuario user) {
        // abrindo a conex�o com o BD
        conexao.conectar();

        try {
            PreparedStatement stm = conexao.getConexao().prepareStatement("update aluno set email = ?, telefone = ?,login = ?,senha = ? "
                    + "where matricula = \'" + user.getMatricula() + "\'");
            stm.setString(1, user.getEmail());
            stm.setString(2, user.getTelefone());
            stm.setString(3, user.getLogin());
            stm.setString(4, user.getSenha());

            stm.execute();
        } catch (SQLException e) {
            System.out.println("Erro: " + e.getMessage());
        } finally {
            // o banco deve ser desconectado, mesmo quando a exce��o � lan�ada
            conexao.desconectar();
        }
    }

    public void editarNotas(int matriculaAluno, int matriculaProfessor, int[] notas) {
        // abrindo a conex�o com o BD
        conexao.conectar();

        try {
            PreparedStatement stm = conexao.getConexao().prepareStatement("update diario set nota1 = ?, nota2 = ?,nota3 = ?,nota4 = ? "
                    + "where aluno = \'" + matriculaAluno + "\' and professor = \'" + matriculaProfessor + "\'");
            stm.setInt(1, notas[0]);
            stm.setInt(2, notas[1]);
            stm.setInt(3, notas[2]);
            stm.setInt(4, notas[3]);

            stm.execute();
        } catch (SQLException e) {
            System.out.println("Erro: " + e.getMessage());
        } finally {
            // o banco deve ser desconectado, mesmo quando a exce��o � lan�ada
            conexao.desconectar();
        }
    }

    public ArrayList<Usuario> verTodosAlunos() {
        ArrayList<Usuario> pessoas = new ArrayList<>();

        // abrindo a conex�o com o BD
        conexao.conectar();
        ResultSet resultado = conexao.executarSQL("select * from aluno");

        try {
            // para iterar sobre os resultados de uma consulta, deve-se utilizar o m�todo next()
            while (resultado.next()) {
                Aluno a = new Aluno();

                String nome = resultado.getString("nome");
                int ano = resultado.getInt("ano");
                int cpf = resultado.getInt("cpf");
                String email = resultado.getString("email");
                String telefone = resultado.getString("telefone");
                String login = resultado.getString("login");
                String senha = resultado.getString("senha");
                int matricula = resultado.getInt("matricula");

                // System.out.println("database.UsuarioDAO.verTodosAlunos()");
                a.setEmail(email);
                a.setTelefone(telefone);
                a.setLogin(login);
                a.setSenha(senha);
                a.setMatricula(matricula);
                a.setAno(ano);
                a.setCPF(cpf);
                a.setNome(nome);

                pessoas.add(a);

            }
        } catch (SQLException e) {
            System.out.println("Erro: " + e.getMessage());
        } finally {
            // o banco deve ser desconectado, mesmo quando a exce��o � lan�ada
            conexao.desconectar();
        }
        return pessoas;
    }

    public ArrayList<Usuario> verTodosProfessor() {
        ArrayList<Usuario> pessoas = new ArrayList<>();
        ArrayList<String> disciplinas = new ArrayList<String>();

        // abrindo a conex�o com o BD
        conexao.conectar();
        ResultSet resultado = conexao.executarSQL("select * from professor");

        try {
            // para iterar sobre os resultados de uma consulta, deve-se utilizar o m�todo next()
            while (resultado.next()) {
                Professor a = new Professor();

                String nome = resultado.getString("nome");
                String disciplina = resultado.getString("disciplina");
                int cpf = resultado.getInt("cpf");
                String email = resultado.getString("email");
                String telefone = resultado.getString("telefone");
                String login = resultado.getString("login");
                String senha = resultado.getString("senha");
                int matricula = resultado.getInt("matricula");

                disciplinas.add(disciplina);

                // System.out.println("database.UsuarioDAO.verTodosAlunos()");
                a.setEmail(email);
                a.setTelefone(telefone);
                a.setLogin(login);
                a.setSenha(senha);
                a.setMatricula(matricula);
                a.setDisciplina(disciplinas);
                a.setCPF(cpf);
                a.setNome(nome);

                pessoas.add(a);

            }
        } catch (SQLException e) {
            System.out.println("Erro: " + e.getMessage());
        } finally {
            // o banco deve ser desconectado, mesmo quando a exce��o � lan�ada
            conexao.desconectar();
        }
        return pessoas;
    }

    public ArrayList<Diario> verDiarios(int matriculaProf) {
        ArrayList<Diario> diarios = new ArrayList<Diario>();
        Diario d1 = new Diario();
        Diario d2 = new Diario();
        Diario d3 = new Diario();
        // abrindo a conex�o com o BD
        conexao.conectar();
        ResultSet resultado = conexao.executarSQL("select * from diario where professor = \'" + matriculaProf + "\'");

        try {
            // para iterar sobre os resultados de uma consulta, deve-se utilizar o m�todo next()
            while (resultado.next()) {
                Aluno a = new Aluno();
                int[] notas = new int[4];

                int matriculaAluno = resultado.getInt("aluno");
                a = buscarAluno(matriculaAluno);
                notas[0] = resultado.getInt("nota1");
                notas[1] = resultado.getInt("nota2");
                notas[2] = resultado.getInt("nota3");
                notas[3] = resultado.getInt("nota4");
                if (a.getAno() == 1) {
                    d1.adicionarAlunoNota(a, notas);
                } else if (a.getAno() == 2) {
                    d2.adicionarAlunoNota(a, notas);
                } else {
                    d3.adicionarAlunoNota(a, notas);
                }
            }
        } catch (SQLException e) {
            System.out.println("Erro: " + e.getMessage());
        } finally {
            // o banco deve ser desconectado, mesmo quando a exce��o � lan�ada
            conexao.desconectar();
        }
        diarios.add(d1);
        diarios.add(d2);
        diarios.add(d3);
        return diarios;
    }

    public ArrayList<Usuario> verTodosTecnico() {
        ArrayList<Usuario> pessoas = new ArrayList<>();

        // abrindo a conex�o com o BD
        conexao.conectar();
        ResultSet resultado = conexao.executarSQL("select * from tecnico");

        try {
            // para iterar sobre os resultados de uma consulta, deve-se utilizar o m�todo next()
            while (resultado.next()) {
                Técnico a = new Técnico();

                String nome = resultado.getString("nome");

                int cpf = resultado.getInt("cpf");
                String email = resultado.getString("email");
                String telefone = resultado.getString("telefone");
                String login = resultado.getString("login");
                String senha = resultado.getString("senha");
                int matricula = resultado.getInt("matricula");

                // System.out.println("database.UsuarioDAO.verTodosAlunos()");
                a.setEmail(email);
                a.setTelefone(telefone);
                a.setLogin(login);
                a.setSenha(senha);
                a.setMatricula(matricula);

                a.setCPF(cpf);
                a.setNome(nome);

                pessoas.add(a);

            }
        } catch (SQLException e) {
            System.out.println("Erro: " + e.getMessage());
        } finally {
            // o banco deve ser desconectado, mesmo quando a exce��o � lan�ada
            conexao.desconectar();
        }
        return pessoas;
    }

    public HashMap<Professor, int[]> verDiariosAluno(int matriculaAluno) {
        HashMap<Professor, int[]> diarios = new HashMap<Professor, int[]>();

        // abrindo a conex�o com o BD
        conexao.conectar();
        ResultSet resultado = conexao.executarSQL("select * from diario where aluno = \'" + matriculaAluno + "\'");

        try {
            // para iterar sobre os resultados de uma consulta, deve-se utilizar o m�todo next()
            while (resultado.next()) {
                Professor p = new Professor();
                int[] notas = new int[4];
                
                int matricula = resultado.getInt("professor");
                p = buscarProfessor(matriculaAluno);
                notas[0] = resultado.getInt("nota1");
                notas[1] = resultado.getInt("nota2");
                notas[2] = resultado.getInt("nota3");
                notas[3] = resultado.getInt("nota4");
                
                diarios.put(p, notas);

            }
        } catch (SQLException e) {
            System.out.println("Erro: " + e.getMessage());
        } finally {
            // o banco deve ser desconectado, mesmo quando a exce��o � lan�ada
            conexao.desconectar();
        }
        
        return diarios;
    }
}

