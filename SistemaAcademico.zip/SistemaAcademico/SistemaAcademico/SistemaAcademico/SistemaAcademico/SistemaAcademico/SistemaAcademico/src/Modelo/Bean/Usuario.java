
package Modelo.Bean;
import Visão.TelaCadastroAluno;

public class  Usuario{


String Nome;
int telefone;
String Email;
int CPF;
int Matricula;
String Senha ;
String login;

    public String getLogin() {
        return login;
    }

    public void setLogin(String login) {
        this.login = login;
    }

    


        public String getSenha() {
            return Senha;
        }

        public void setSenha(String  Senha) {
            this.Senha = Senha;
        }

  
        

        public String getNome() {
		return Nome;
	}
	public void setNome(String nome) {
		Nome = nome;
	}
	public  int getTelefone() {
		return telefone;
	}
	 public void setTelefone(int telefone) {
		this.telefone = telefone;
	}
	 public String getEmail() {
		return Email;
	}
	 public void setEmail(String email) {
		Email = email;
	}

        public void setMatricula(String Matricula) {
		Matricula = Matricula;
	}
         public int getMatricula() {
		return Matricula;
	}

        public int getCPF() {
            return CPF;
        }

        public void setCPF(int CPF) {
            this.CPF = CPF;
        }

    public void getSenha(int parseInt) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
         
}