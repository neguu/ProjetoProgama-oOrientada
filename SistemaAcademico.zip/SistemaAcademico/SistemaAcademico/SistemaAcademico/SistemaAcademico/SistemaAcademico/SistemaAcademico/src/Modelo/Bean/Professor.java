
package Modelo.Bean;


public class Professor extends Usuario {

String Disciplina;


public String getDisciplina() {
	return Disciplina;
}
public void setDisciplina(String disciplina) {
	Disciplina = disciplina;
}
public int getMatricula() {
	return Matricula;
}
public void setMatricula(int matricula) {
	Matricula = matricula;
}

 


}