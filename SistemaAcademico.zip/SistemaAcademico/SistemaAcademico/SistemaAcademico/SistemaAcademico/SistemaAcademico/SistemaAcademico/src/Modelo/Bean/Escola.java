/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo.Bean;

import java.util.ArrayList;

/**
 *
 * @author ifpb
 */
public class Escola {
    
    public ArrayList<Usuario> alunos = new ArrayList<Usuario>();

    public Escola() {
      Aluno aluno1 = new Aluno();
       Aluno aluno2 = new Aluno();
       aluno1.setNome("AAAAA");
       aluno1.setSenha("123");
       aluno1.setEmail("emai1@g1");
       aluno2.setSenha("123");
        aluno2.setNome("NOME2");
        aluno2.setEmail("emai2@g2");
        aluno1.setCPF(231654);
        
        alunos.add(aluno2);
        alunos.add(aluno1);
    }
    
    public int compare(Usuario o1, Usuario o2) {
        return o1.getNome().compareTo(o2.getNome());
    }
    
    
    
}
