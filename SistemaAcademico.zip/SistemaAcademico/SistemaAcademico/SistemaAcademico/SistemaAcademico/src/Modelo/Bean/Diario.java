
package Modelo.Bean;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;


public class Diario {
    
    String disciplina;
    Professor professor;
    Map<Aluno,int[]> alunos = new HashMap<>();
    
    public Map<Aluno,int[]> getAlunos() {
        return alunos;
    }

    public void setAlunos(Map<Aluno,int[]> alunos) {
        this.alunos = alunos;
    }
    public String getDisciplina() {
        return disciplina;
    }

    public void setDisciplina(String disciplina) {
        this.disciplina = disciplina;
    }

    public void setProfessor(Professor p) {
        this.professor = p;
    }
    public Professor getProfessor(){
        return professor;
    }

    public void adicionarAluno(Aluno a){
        int[] n = new int[4]; 
        alunos.put(a, n); 
         
      
    }
    
    
}
