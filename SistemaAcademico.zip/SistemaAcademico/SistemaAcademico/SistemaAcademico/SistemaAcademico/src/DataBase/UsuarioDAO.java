package database;

import Modelo.Bean.Aluno;
import Modelo.Bean.Professor;
import Modelo.Bean.Técnico;
import Modelo.Bean.Usuario;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;

import java.sql.ResultSet;

public class UsuarioDAO {

    private ConexaoBD conexao;

    public UsuarioDAO() {
        // cria o objeto para conex�o com banco, por�m n�o o inicializa
        // a conex�o deve ser aberta e, consequentemente, fechada durante o envio de comandos
        // ao banco
        this.conexao = new ConexaoBD();
    }

    public void criarPessoa(Usuario u) {
        // abrindo a conex�o com o BD
        conexao.conectar();

        try {
            if (u instanceof Aluno) {
                // usando um PreparedStatement com valores externos como par�metros (representados pelo '?')
                PreparedStatement pst = conexao.getConexao().prepareStatement("insert into aluno(nome,email,telefone,login,senha,cpf,ano,matricula) values(?,?,?,?,?,?,?,?)");
                // os m�todos set devem ser escolhidos de acordo com os tipos dos atributos da entidade que est�
                // sendo acessada. A sequ�ncia � determinada por �ndices, iniciando do valor 1.
                pst.setString(1, u.getNome());
                pst.setString(2, u.getEmail());
                pst.setString(3, u.getTelefone());
                pst.setString(4, u.getLogin());
                pst.setString(5, u.getSenha());
                pst.setInt(6, u.getCPF());
                pst.setInt(7, u.getAno());
                System.out.println(u.getMatricula());
                pst.setInt(8, u.getMatricula());

                // solicita��o da execu��o da query, ap�s seu preparo
                pst.execute();

            } else if (u instanceof Professor) {
                // usando um PreparedStatement com valores externos como par�metros (representados pelo '?')
                PreparedStatement pst = conexao.getConexao().prepareStatement("insert into professor(nome,email,telefone,login,senha,cpf,matricula,disciplina) values(?,?,?,?,?,?,?,?)");
                // os m�todos set devem ser escolhidos de acordo com os tipos dos atributos da entidade que est�
                // sendo acessada. A sequ�ncia � determinada por �ndices, iniciando do valor 1.
                pst.setString(1, u.getNome());
                pst.setString(2, u.getEmail());
                pst.setString(3, u.getTelefone());
                pst.setString(4, u.getLogin());
                pst.setString(5, u.getSenha());
                pst.setInt(6, u.getCPF());
                pst.setInt(7, u.getMatricula());
                Professor p = (Professor) u;
                pst.setString(8, p.getDisciplina());

                // solicita��o da execu��o da query, ap�s seu preparo
                pst.execute();

            } else if (u instanceof Técnico) {
                // usando um PreparedStatement com valores externos como par�metros (representados pelo '?')
                PreparedStatement pst = conexao.getConexao().prepareStatement("insert into tecnico(nome,email,telefone,login,senha,cpf,matricula) values(?,?,?,?,?,?,?)");
                // os m�todos set devem ser escolhidos de acordo com os tipos dos atributos da entidade que est�
                // sendo acessada. A sequ�ncia � determinada por �ndices, iniciando do valor 1.
                pst.setString(1, u.getNome());
                pst.setString(2, u.getEmail());
                pst.setString(3, u.getTelefone());
                pst.setString(4, u.getLogin());
                pst.setString(5, u.getSenha());
                pst.setInt(6, u.getCPF());
                pst.setInt(7, u.getMatricula());

                // solicita��o da execu��o da query, ap�s seu preparo
                pst.execute();

            }

        } catch (SQLException e) {
            System.out.println("Erro: " + e.getMessage());
        } finally {
            // o banco deve ser desconectado, mesmo quando a exce��o � lan�ada
            conexao.desconectar();
        }

    }

    // busca de pessoas por seu c�digo de identifica��o no banco (id)
    public Usuario buscarPessoa(int matricula, Usuario u) {
        
        if (u instanceof Professor) {

            conexao.conectar();
            // busca utilizando o m�todo de consulta do objeto ConexaoBD
            ResultSet resultado = conexao.executarSQL("select * from professor where matricula = \'" + matricula + "\'");

            Professor p = new Professor();
            try {
                resultado.next();
                // os m�todos get devem ser escolhidos de acordo com os tipos dos atributos da entidade que est�
                // sendo acessada
                String nome = resultado.getString("nome");
                String email = resultado.getString("email");
                String telefone = resultado.getString("telefone");
                String login = resultado.getString("login");
                String senha = resultado.getString("senha");
                int cpf = resultado.getInt("cpf");
                int matricula1 = resultado.getInt("matricula");
                String disciplina = resultado.getString("disciplina");

                ArrayList<String> disc = new ArrayList<>();
                disc.add(disciplina);
                p.setNome(nome);
                p.setEmail(email);
                p.setTelefone(telefone);
                p.setLogin(login);
                p.setSenha(senha);
                p.setCPF(cpf);
                p.setMatricula(matricula1);
                p.setDisciplina(disc);

            } catch (SQLException e) {
                System.out.println("Erro: " + e.getMessage());
            } finally {
                // o banco deve ser desconectado, mesmo quando a exce��o � lan�ada
                conexao.desconectar();
            }

        } else if (u instanceof Aluno) {

            Aluno a = new Aluno();

            try {
                ResultSet resultado = conexao.executarSQL("select * from aluno where matricula = \'" + matricula + "\'");
                resultado.next();
                // os m�todos get devem ser escolhidos de acordo com os tipos dos atributos da entidade que est�
                // sendo acessada
                String nome = resultado.getString("nome");
                String email = resultado.getString("email");
                String telefone = resultado.getString("telefone");
                String login = resultado.getString("login");
                String senha = resultado.getString("senha");
                int cpf = resultado.getInt("cpf");
                int matricula1 = resultado.getInt("matricula");
                int ano = resultado.getInt("ano");

                a.setNome(nome);
                a.setEmail(email);
                a.setTelefone(telefone);
                a.setLogin(login);
                a.setSenha(senha);
                a.setCPF(cpf);
                a.setMatricula(matricula1);
                a.setAno(ano);

            } catch (SQLException e) {
                System.out.println("Erro: " + e.getMessage());
            } finally {
                // o banco deve ser desconectado, mesmo quando a exce��o � lan�ada
                conexao.desconectar();
            }

        }
        return u;
    }

    public void excluirPessoa(int matricula, Usuario u) {
        // abrindo a conex�o com o BD
        conexao.conectar();

        try {
            if (u instanceof Aluno) {
                PreparedStatement stm = conexao.getConexao().prepareStatement("delete from aluno where matricula = \'" + matricula + "\'");
                stm.execute();
            } else if (u instanceof Professor) {
                PreparedStatement stm = conexao.getConexao().prepareStatement("delete from professor where matricula = \'" + matricula + "\'");
                stm.execute();
            } else if (u instanceof Técnico) {
                PreparedStatement stm = conexao.getConexao().prepareStatement("delete from tecnico where matricula = \'" + matricula + "\'");
                stm.execute();

            }

        } catch (SQLException e) {
            System.out.println("Erro: " + e.getMessage());
        } finally {
            // o banco deve ser desconectado, mesmo quando a exce��o � lan�ada
            conexao.desconectar();
        }
    }

    public void editarPessoa(String nome, String curso) {
        // abrindo a conex�o com o BD
        conexao.conectar();

        try {
            PreparedStatement stm = conexao.getConexao().prepareStatement("update usuario set nome = ?, curso = ? "
                    + "where id = \'" + 1 + "\'");
            stm.setString(1, nome);
            stm.setString(2, curso);
            stm.execute();
        } catch (SQLException e) {
            System.out.println("Erro: " + e.getMessage());
        } finally {
            // o banco deve ser desconectado, mesmo quando a exce��o � lan�ada
            conexao.desconectar();
        }
    }

    public ArrayList<Usuario> verTodos() {
        ArrayList<Usuario> pessoas = new ArrayList<>();

        // abrindo a conex�o com o BD
        conexao.conectar();
        ResultSet resultado = conexao.executarSQL("select * from usuario");

        try {
            // para iterar sobre os resultados de uma consulta, deve-se utilizar o m�todo next()
            while (resultado.next()) {
                String nomePessoa = resultado.getString("nome");
                String curso = resultado.getString("curso");
                // pessoas.add(new Usuario(nomePessoa, curso));
            }
        } catch (SQLException e) {
            System.out.println("Erro: " + e.getMessage());
        } finally {
            // o banco deve ser desconectado, mesmo quando a exce��o � lan�ada
            conexao.desconectar();
        }
        return pessoas;
    }

}
