
package Modelo.Bean;

import java.util.ArrayList;


public class Professor extends Usuario {

    ArrayList<String> disciplinas = new ArrayList<String>();


public String getDisciplina() {
        String discs = " ";
    
        for (int n = 0; n <  disciplinas.size(); n++){
            discs = discs + disciplinas.get(n) + " ";
            System.out.println(discs);
        }    
         return discs;
        
}
//public void setDisciplina(String disciplina) {;
//	Disciplina = disciplina;
//}
public int getMatricula() {
	return Matricula;
}
public void setMatricula(int matricula) {
	Matricula = matricula;
}

    public void setDisciplina(ArrayList<String> disciplinas) {
        this.disciplinas = disciplinas;
    }

    void adicionarDisciplina(String disciplina) {
        disciplinas.add(disciplina);
    }

 


}