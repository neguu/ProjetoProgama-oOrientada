package Modelo.Bean;

public class Usuario {

    String Nome;
    String telefone;
    String Email;
    int CPF;
    int Matricula;
    String Senha;
    String login;

    public int getAno() {
        return -1;
    }

    public void setAno() {
    }

    public String getLogin() {
        return login;
    }

    public void setLogin(String login) {
        this.login = login;
    }

    public String getSenha() {
        return Senha;
    }

    public void setSenha(String Senha) {
        this.Senha = Senha;
    }

    public String getNome() {
        return Nome;
    }

    public void setNome(String nome) {
        Nome = nome;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public String getEmail() {
        return Email;
    }

    public void setEmail(String email) {
        Email = email;
    }

    public void setMatricula(int Matricula) {
        this.Matricula = Matricula;
    }

    public int getMatricula() {
        return Matricula;
    }

    public int getCPF() {
        return CPF;
    }

    public void setCPF(int CPF) {
        this.CPF = CPF;
    }

    public void setAno(int ano) {
    }
    

    public String getDisciplina() {
        String discs = " ";

        return discs;

    }

}
