
package Modelo.Bean;

public class  Usuario{


String Nome;
int telefone;
String Email;
int CPF;
int Matricula;

  
        

        private String getNome() {
		return Nome;
	}
	private void setNome(String nome) {
		Nome = nome;
	}
	private int getTelefone() {
		return telefone;
	}
	private void setTelefone(int telefone) {
		this.telefone = telefone;
	}
	private String getEmail() {
		return Email;
	}
	private void setEmail(String email) {
		Email = email;
	}


}