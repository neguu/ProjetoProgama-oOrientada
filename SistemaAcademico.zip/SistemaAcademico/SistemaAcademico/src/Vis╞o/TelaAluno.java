/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Visão;

import Modelo.Bean.Aluno;
import Modelo.Bean.Escola;
import Modelo.Bean.Usuario;

/**
 *
 * @author ifpb
 */
public class TelaAluno extends javax.swing.JFrame {

     Aluno aluno = new Aluno();
     Escola escola = new Escola();
     
     
     
     public TelaAluno(Aluno aluno ,Escola escola ) {
        this.aluno = aluno;
        this.escola = escola;
        initComponents();
    }
     
     
    public TelaAluno() {
        initComponents();
    }

   

 
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        AlterarDados = new javax.swing.JButton();
        Disciplinas = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();
        gif = new javax.swing.JLabel();
        TAluno = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(null);

        AlterarDados.setFont(new java.awt.Font("Verdana", 3, 18)); // NOI18N
        AlterarDados.setForeground(new java.awt.Color(0, 0, 255));
        AlterarDados.setText("Alterar Dados Pessoais");
        AlterarDados.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AlterarDadosActionPerformed(evt);
            }
        });
        getContentPane().add(AlterarDados);
        AlterarDados.setBounds(20, 30, 270, 80);

        Disciplinas.setFont(new java.awt.Font("Verdana", 3, 24)); // NOI18N
        Disciplinas.setForeground(new java.awt.Color(102, 102, 255));
        Disciplinas.setText("Disciplinas");
        Disciplinas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DisciplinasActionPerformed(evt);
            }
        });
        getContentPane().add(Disciplinas);
        Disciplinas.setBounds(340, 30, 290, 80);

        jButton1.setFont(new java.awt.Font("Verdana", 3, 24)); // NOI18N
        jButton1.setText("sair");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton1);
        jButton1.setBounds(670, 30, 210, 80);

        gif.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagens/cavalo.gif"))); // NOI18N
        getContentPane().add(gif);
        gif.setBounds(160, 160, 500, 220);

        TAluno.setForeground(new java.awt.Color(0, 51, 51));
        TAluno.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagens/TelaAluno.jpg"))); // NOI18N
        getContentPane().add(TAluno);
        TAluno.setBounds(0, 0, 960, 427);

        setBounds(0, 0, 976, 465);
    }// </editor-fold>//GEN-END:initComponents

    private void AlterarDadosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AlterarDadosActionPerformed
         TelaAlterar t = new TelaAlterar(aluno, escola );
         t.setVisible(true);
         dispose();
    }//GEN-LAST:event_AlterarDadosActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
            System.exit(1);
    }//GEN-LAST:event_jButton1ActionPerformed

    private void DisciplinasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DisciplinasActionPerformed
            TelaNota tn = new TelaNota(aluno, escola );
            tn.setVisible(true);
            dispose();
    }//GEN-LAST:event_DisciplinasActionPerformed

   
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(TelaAluno.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(TelaAluno.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(TelaAluno.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(TelaAluno.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new TelaAluno().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton AlterarDados;
    private javax.swing.JButton Disciplinas;
    private javax.swing.JLabel TAluno;
    private javax.swing.JLabel gif;
    private javax.swing.JButton jButton1;
    // End of variables declaration//GEN-END:variables
}
